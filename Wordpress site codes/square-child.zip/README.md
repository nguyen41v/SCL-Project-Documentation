#This is a child theme of Square on WordPress
-Insert some more info later-



##Version Updates
###Version 1.0.1
* (Change) Changed the home page slider to be a fixed sized of 900 x 400 by adding and changing front-page.php

###Version 1.0.0
* (Update) Initialization of theme by creating a style.css and a functions.php file